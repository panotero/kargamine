<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientProposalRate extends Model
{
    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected $fillable = [
        'proposal_id',
        'origin_port_id',
        'origin_pickup_area_id',
        'destination_port_id',
        'destination_pickup_area_id',
        'container_id',
        'container_class_id',
        'container_size_id',
        'container_variant_id',
        'min_van_qty',
        'base_rate',
        'discount_type',
        'discount_value',
        'final_rate',
    ];

    public function proposal()
    {
        return $this->belongsTo(ClientProposal::class, 'proposal_id');
    }

    public function originPort()
    {
        return $this->belongsTo(Port::class, 'origin_port_id', 'port_id');
    }

    public function destinationPort()
    {
        return $this->belongsTo(Port::class, 'destination_port_id', 'port_id');
    }

    public function originPickupArea()
    {
        return $this->belongsTo(ServiceableArea::class, 'origin_pickup_area_id', 'area_id');
    }

    public function destinationPickupArea()
    {
        return $this->belongsTo(ServiceableArea::class, 'destination_pickup_area_id', 'area_id');
    }

    public function container()
    {
        return $this->belongsTo(Container::class);
    }

    public function containerClass()
    {
        return $this->belongsTo(ContainerClass::class, 'container_class_id');
    }

    public function containerSize()
    {
        return $this->belongsTo(ContainerSize::class, 'container_size_id');
    }

    public function variant()
    {
        return $this->belongsTo(ContainerVariant::class, 'container_variant_id');
    }

    public function ancillaryServices()
    {
        return $this->hasMany(ClientProposalRateAncillaryService::class, 'proposal_rate_id');
    }
}
