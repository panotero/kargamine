<?php

namespace App\Http\Controllers;

use App\Models\ContainerAsset;
use App\Models\ContainerAssetLocationHistory;
use App\Services\ContainerReservationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use RuntimeException;

class ContainerAssetController extends Controller
{
    public function __construct(protected ContainerReservationService $reservationService) {}

    protected function withDisplayRelations($query)
    {
        return $query->with([
            'containerVariant.container',
            'containerVariant.containerClass',
            'containerVariant.containerSize',
            'currentPort.location',
        ]);
    }

    /**
     * Shared by index()'s list query and its status_counts sibling below -
     * every filter except status itself, so switching status chips doesn't
     * reset the other filters and each chip's count reflects them.
     */
    protected function scopedQuery(Request $request)
    {
        return ContainerAsset::query()
            ->when($request->filled('container_variant_id'), fn ($q) => $q->where('container_variant_id', $request->container_variant_id))
            ->when($request->filled('current_port_id'), fn ($q) => $q->where('current_port_id', $request->current_port_id))
            ->when($request->filled('search'), fn ($q) => $q->where('container_no', 'like', "%{$request->search}%"));
    }

    public function index(Request $request)
    {
        $assets = $this->withDisplayRelations($this->scopedQuery($request))
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->status))
            ->latest('id')
            ->paginate($request->get('per_page', 25));

        $statusCounts = $this->scopedQuery($request)
            ->selectRaw('status, count(*) as total')->groupBy('status')->pluck('total', 'status');

        return response()->json([
            'success' => true,
            'data' => $assets,
            'status_counts' => [
                'all' => $statusCounts->sum(),
                'available' => $statusCounts->get(ContainerAsset::STATUS_AVAILABLE, 0),
                'booked' => $statusCounts->get(ContainerAsset::STATUS_BOOKED, 0),
                'in_transit' => $statusCounts->get(ContainerAsset::STATUS_IN_TRANSIT, 0),
                'under_repair' => $statusCounts->get(ContainerAsset::STATUS_UNDER_REPAIR, 0),
                'damaged' => $statusCounts->get(ContainerAsset::STATUS_DAMAGED, 0),
                'out_of_service' => $statusCounts->get(ContainerAsset::STATUS_OUT_OF_SERVICE, 0),
            ],
        ]);
    }

    public function show(ContainerAsset $containerAsset)
    {
        $containerAsset->load([
            'containerVariant.container',
            'containerVariant.containerClass',
            'containerVariant.containerSize',
            'currentPort.location',
            'locationHistory' => fn ($q) => $q->with(['port.location', 'recordedBy'])->limit(20),
            // Only meaningful while Booked/In Transit - lets the UI name and
            // link the booking currently holding this container instead of
            // just hiding every action with no explanation.
            'activeBookingUnit.booking:booking_id,code',
        ]);

        return response()->json([
            'success' => true,
            'data' => $containerAsset,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'container_variant_id' => ['required', 'integer', 'exists:container_variants,id'],
            'container_no' => ['required', 'string', 'max:20', 'unique:container_assets,container_no'],
            'current_port_id' => ['nullable', 'integer', 'exists:ports,port_id'],
            'current_pier_reference' => ['nullable', 'string', 'max:100'],
            'condition_notes' => ['nullable', 'string'],
        ]);

        $asset = DB::transaction(function () use ($validated, $request) {
            $asset = ContainerAsset::create([
                'container_variant_id' => $validated['container_variant_id'],
                'container_no' => strtoupper($validated['container_no']),
                'status' => ContainerAsset::STATUS_AVAILABLE,
                'current_port_id' => $validated['current_port_id'] ?? null,
                'current_pier_reference' => $validated['current_pier_reference'] ?? null,
                'condition_notes' => $validated['condition_notes'] ?? null,
            ]);

            if ($asset->current_port_id) {
                $asset->applyChange(
                    ['current_port_id' => $asset->current_port_id, 'current_pier_reference' => $asset->current_pier_reference],
                    ContainerAssetLocationHistory::SOURCE_MANUAL_RELOCATION,
                    $request->user()?->id
                );
            }

            return $asset;
        });

        return response()->json([
            'success' => true,
            'data' => $asset,
        ], 201);
    }

    public function update(Request $request, ContainerAsset $containerAsset)
    {
        $validated = $request->validate([
            'container_no' => [
                'sometimes',
                'string',
                'max:20',
                Rule::unique('container_assets', 'container_no')->ignore($containerAsset->id),
            ],
            'condition_notes' => ['nullable', 'string'],
        ]);

        if (isset($validated['container_no'])) {
            $validated['container_no'] = strtoupper($validated['container_no']);
        }

        $containerAsset->update($validated);

        return response()->json([
            'success' => true,
            'data' => $containerAsset,
        ]);
    }

    public function markUnderRepair(Request $request, ContainerAsset $containerAsset)
    {
        $validated = $request->validate([
            'reason' => ['nullable', 'string', 'max:500'],
        ]);

        if (in_array($containerAsset->status, [ContainerAsset::STATUS_BOOKED, ContainerAsset::STATUS_IN_TRANSIT], true)) {
            return response()->json([
                'success' => false,
                'message' => 'This container is booked or in transit - release it from its booking before marking it under repair.',
            ], 422);
        }

        if ($containerAsset->status === ContainerAsset::STATUS_UNDER_REPAIR) {
            return response()->json([
                'success' => false,
                'message' => 'This container is already under repair.',
            ], 422);
        }

        $containerAsset->applyChange(
            ['status' => ContainerAsset::STATUS_UNDER_REPAIR],
            ContainerAssetLocationHistory::SOURCE_MANUAL_RELOCATION,
            $request->user()?->id
        );

        if (! empty($validated['reason'])) {
            $containerAsset->update(['condition_notes' => $validated['reason']]);
        }

        return response()->json([
            'success' => true,
            'data' => $containerAsset->fresh(),
        ]);
    }

    public function markAvailable(Request $request, ContainerAsset $containerAsset)
    {
        if (! in_array($containerAsset->status, [ContainerAsset::STATUS_UNDER_REPAIR, ContainerAsset::STATUS_DAMAGED], true)) {
            return response()->json([
                'success' => false,
                'message' => 'Only a container currently Under Repair or Damaged can be marked Available this way.',
            ], 422);
        }

        $containerAsset->applyChange(
            ['status' => ContainerAsset::STATUS_AVAILABLE],
            ContainerAssetLocationHistory::SOURCE_MANUAL_RELOCATION,
            $request->user()?->id
        );

        return response()->json([
            'success' => true,
            'data' => $containerAsset->fresh(),
        ]);
    }

    public function markOutOfService(Request $request, ContainerAsset $containerAsset)
    {
        $validated = $request->validate([
            'reason' => ['nullable', 'string', 'max:500'],
        ]);

        if (in_array($containerAsset->status, [ContainerAsset::STATUS_BOOKED, ContainerAsset::STATUS_IN_TRANSIT], true)) {
            return response()->json([
                'success' => false,
                'message' => 'This container is booked or in transit - release it from its booking first.',
            ], 422);
        }

        $containerAsset->applyChange(
            ['status' => ContainerAsset::STATUS_OUT_OF_SERVICE],
            ContainerAssetLocationHistory::SOURCE_MANUAL_RELOCATION,
            $request->user()?->id
        );

        if (! empty($validated['reason'])) {
            $containerAsset->update(['condition_notes' => $validated['reason']]);
        }

        return response()->json([
            'success' => true,
            'data' => $containerAsset->fresh(),
        ]);
    }

    public function markDamaged(Request $request, ContainerAsset $containerAsset)
    {
        $validated = $request->validate([
            'reason' => ['nullable', 'string', 'max:500'],
        ]);

        if (in_array($containerAsset->status, [ContainerAsset::STATUS_BOOKED, ContainerAsset::STATUS_IN_TRANSIT], true)) {
            return response()->json([
                'success' => false,
                'message' => 'This container is booked or in transit - release it from its booking before marking it damaged.',
            ], 422);
        }

        if ($containerAsset->status === ContainerAsset::STATUS_DAMAGED) {
            return response()->json([
                'success' => false,
                'message' => 'This container is already marked damaged.',
            ], 422);
        }

        $containerAsset->applyChange(
            ['status' => ContainerAsset::STATUS_DAMAGED],
            ContainerAssetLocationHistory::SOURCE_MANUAL_RELOCATION,
            $request->user()?->id
        );

        if (! empty($validated['reason'])) {
            $containerAsset->update(['condition_notes' => $validated['reason']]);
        }

        return response()->json([
            'success' => true,
            'data' => $containerAsset->fresh(),
        ]);
    }

    public function relocate(Request $request, ContainerAsset $containerAsset)
    {
        $validated = $request->validate([
            'port_id' => ['required', 'integer', 'exists:ports,port_id'],
            'pier_reference' => ['nullable', 'string', 'max:100'],
        ]);

        $containerAsset->applyChange(
            [
                'current_port_id' => $validated['port_id'],
                'current_pier_reference' => $validated['pier_reference'] ?? null,
            ],
            ContainerAssetLocationHistory::SOURCE_MANUAL_RELOCATION,
            $request->user()?->id
        );

        return response()->json([
            'success' => true,
            'data' => $containerAsset->fresh(),
        ]);
    }

    /**
     * Ranked candidate list for a booking line: same current port as the
     * booking's origin first, then longest-idle. Used directly by the
     * manual-pick dropdown, and internally by reserve()'s auto mode -
     * both paths agree on what "best available" means.
     */
    public function available(Request $request)
    {
        $validated = $request->validate([
            'container_variant_id' => ['required', 'integer', 'exists:container_variants,id'],
            'origin_port_id' => ['nullable', 'integer', 'exists:ports,port_id'],
            'quantity' => ['nullable', 'integer', 'min:1'],
        ]);

        $assets = $this->withDisplayRelations(
            $this->reservationService->rankedAvailableQuery(
                $validated['container_variant_id'],
                $validated['origin_port_id'] ?? null
            )
        )
            ->when($validated['quantity'] ?? null, fn ($q, $qty) => $q->limit($qty))
            ->get();

        return response()->json([
            'success' => true,
            'data' => $assets,
        ]);
    }

    public function reserve(Request $request)
    {
        $validated = $request->validate([
            'auto' => ['sometimes', 'boolean'],
            'container_asset_ids' => ['required_if:auto,false', 'array'],
            'container_asset_ids.*' => ['integer', 'exists:container_assets,id'],
            'container_variant_id' => ['required_if:auto,true', 'integer', 'exists:container_variants,id'],
            'origin_port_id' => ['nullable', 'integer', 'exists:ports,port_id'],
            'quantity' => ['required_if:auto,true', 'integer', 'min:1'],
        ]);

        try {
            $assets = DB::transaction(function () use ($validated, $request) {
                if ($request->boolean('auto')) {
                    return $this->reservationService->reserveAuto(
                        $validated['container_variant_id'],
                        $validated['origin_port_id'] ?? null,
                        $validated['quantity'],
                        $request->user()?->id
                    );
                }

                return $this->reservationService->reserveExplicit(
                    $validated['container_asset_ids'],
                    $request->user()?->id
                );
            });
        } catch (RuntimeException $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 422);
        }

        return response()->json(['success' => true, 'data' => $assets]);
    }

    public function release(Request $request)
    {
        $validated = $request->validate([
            'container_asset_ids' => ['required', 'array', 'min:1'],
            'container_asset_ids.*' => ['integer', 'exists:container_assets,id'],
        ]);

        try {
            $assets = DB::transaction(
                fn () => $this->reservationService->release($validated['container_asset_ids'], $request->user()?->id)
            );
        } catch (RuntimeException $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 422);
        }

        return response()->json(['success' => true, 'data' => $assets]);
    }
}
