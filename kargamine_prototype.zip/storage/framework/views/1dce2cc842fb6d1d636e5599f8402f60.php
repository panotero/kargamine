
<div id="ProposalRequestsMinePage" class="container mx-auto p-3">

    <div class="flex justify-between items-center mb-5 p-2">
        <div>
            <h1 class="text-2xl font-bold">My Proposal Requests</h1>
            <p class="text-zinc-500">Proposal requests assigned to you as CSR or Relationship Manager</p>
        </div>
    </div>

    
    <section class="w-full my-5">
        <div class="flex items-center flex-wrap gap-2">
            <div class="prmStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 border-dashed border-zinc-300 text-zinc-500 dark:border-zinc-600 dark:text-zinc-400"
                data-status="all">
                <span>All</span>
                <span id="prmCountAll">0</span>
            </div>
            <div class="prmStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 text-blue-600 border-blue-300 dark:text-blue-400 dark:border-blue-700"
                data-status="assigned">
                <span>Assigned</span>
                <span id="prmCountAssigned">0</span>
            </div>
            <div class="prmStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 text-amber-600 border-amber-300 dark:text-amber-400 dark:border-amber-700"
                data-status="for_approval">
                <span>For Approval</span>
                <span id="prmCountForApproval">0</span>
            </div>
            <div class="prmStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 text-green-600 border-green-300 dark:text-green-400 dark:border-green-700"
                data-status="approved">
                <span>Approved</span>
                <span id="prmCountApproved">0</span>
            </div>
            <div class="prmStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 text-green-600 border-green-300 dark:text-green-400 dark:border-green-700"
                data-status="signed">
                <span>Signed</span>
                <span id="prmCountSigned">0</span>
            </div>
            <div class="prmStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 border-dashed text-zinc-500 border-zinc-300 dark:text-zinc-400 dark:border-zinc-600"
                data-status="cancelled">
                <span>Cancelled</span>
                <span id="prmCountCancelled">0</span>
            </div>
        </div>
    </section>

    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'tableProposalRequestsMine']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
</div>

<?php if (isset($component)) { $__componentOriginal5c984bd715f18cdb9e98481f8335a762 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c984bd715f18cdb9e98481f8335a762 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.request-proposal-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('request-proposal-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c984bd715f18cdb9e98481f8335a762)): ?>
<?php $attributes = $__attributesOriginal5c984bd715f18cdb9e98481f8335a762; ?>
<?php unset($__attributesOriginal5c984bd715f18cdb9e98481f8335a762); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c984bd715f18cdb9e98481f8335a762)): ?>
<?php $component = $__componentOriginal5c984bd715f18cdb9e98481f8335a762; ?>
<?php unset($__componentOriginal5c984bd715f18cdb9e98481f8335a762); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalb54267e83da368667c6cdc6fc816bbc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb54267e83da368667c6cdc6fc816bbc3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.proposal-request-summary-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('proposal-request-summary-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb54267e83da368667c6cdc6fc816bbc3)): ?>
<?php $attributes = $__attributesOriginalb54267e83da368667c6cdc6fc816bbc3; ?>
<?php unset($__attributesOriginalb54267e83da368667c6cdc6fc816bbc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb54267e83da368667c6cdc6fc816bbc3)): ?>
<?php $component = $__componentOriginalb54267e83da368667c6cdc6fc816bbc3; ?>
<?php unset($__componentOriginalb54267e83da368667c6cdc6fc816bbc3); ?>
<?php endif; ?>

<script>
    (function () {
        window.initRequestProposalModal?.();
        window.initProposalRequestsMinePage?.();
    })();
</script>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/pages/proposal_requests_mine.blade.php ENDPATH**/ ?>