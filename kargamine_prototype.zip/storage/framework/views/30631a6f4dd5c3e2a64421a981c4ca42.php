<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'align' => 'right',
    'width' => '48',
    'contentClasses' => 'w-auto py-1 bg-white dark:bg-gray-700',
    'showProfile' => true,
    'showSettings' => true,
    'showLogout' => true,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'align' => 'right',
    'width' => '48',
    'contentClasses' => 'w-auto py-1 bg-white dark:bg-gray-700',
    'showProfile' => true,
    'showSettings' => true,
    'showLogout' => true,
]); ?>
<?php foreach (array_filter(([
    'align' => 'right',
    'width' => '48',
    'contentClasses' => 'w-auto py-1 bg-white dark:bg-gray-700',
    'showProfile' => true,
    'showSettings' => true,
    'showLogout' => true,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    switch ($align) {
        case 'left':
            $alignmentClasses = 'ltr:origin-top-left rtl:origin-top-right start-0';
            break;
        case 'top':
            $alignmentClasses = 'origin-top';
            break;
        case 'right':
        default:
            $alignmentClasses = 'ltr:origin-top-right rtl:origin-top-left end-0';
            break;
    }

    switch ($width) {
        case '48':
            $width = 'w-48';
            break;
    }
?>

<div class="relative" x-data="{ open: false }" @click.outside="open = false" @close.stop="open = false">
    <!-- Trigger -->
    <div @click="open = ! open">
        <?php echo e($trigger); ?>

    </div>

    <!-- Dropdown Content -->
    <div x-show="open" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 scale-95"
        x-transition:enter-end="opacity-100 scale-100" x-transition:leave="transition ease-in duration-75"
        x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95"
        class="absolute z-50 mt-2 <?php echo e($width); ?> rounded-md shadow-lg <?php echo e($alignmentClasses); ?>"
        style="display: none;">

        <div class="rounded-md ring-1 ring-black ring-opacity-5 <?php echo e($contentClasses); ?>">

            <!-- User Avatar + Email -->
            <div class="flex items-start justify-center  p-4">
                <div id="dropdownAvatarWrap">

                    <?php if(Auth::user()->profile_photo_url): ?>
                        <img src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="Avatar"
                            class="h-16 w-16 rounded-full object-cover">
                    <?php else: ?>
                        <div
                            class="h-16 w-16 rounded-full bg-gray-400 text-white flex items-center justify-center font-semibold">
                            <?php echo e(strtoupper(substr(Auth::user()->name, 0, 1))); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class=" px-3">

                    <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e(Auth::user()->email); ?></p>
                    <p id="dropdownUserName" class="text-sm text-gray-700 dark:text-gray-300"><?php echo e(Auth::user()->name); ?></p>
                </div>
            </div>

            <button type="button" @click="open = false"
                onclick="window.loadPage({title: 'My Profile', link: '/page_profile'})"
                class="block w-full px-4 py-2 text-start text-sm leading-5 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 focus:outline-none focus:bg-gray-100 dark:focus:bg-gray-800 transition duration-150 ease-in-out">
                <?php echo e(__('My Profile')); ?>

            </button>

            <div class="border-t border-gray-200 dark:border-gray-600 my-1"></div>

            
            <?php if($showLogout): ?>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                        class="block w-full px-4 py-2 text-start text-sm leading-5 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 focus:outline-none focus:bg-gray-100 dark:focus:bg-gray-800 transition duration-150 ease-in-out">
                        <?php echo e(__('Log Out')); ?>

                    </button>
                </form>
            <?php endif; ?>

            
            <?php echo e($content); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/components/dropdown.blade.php ENDPATH**/ ?>