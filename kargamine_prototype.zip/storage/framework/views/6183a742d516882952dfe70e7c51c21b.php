<div class="container mx-auto px-4 py-6">

    <div class="flex items-center justify-between mb-6">

        <div>
            <h1 class="text-2xl font-bold">Contracts</h1>
            <p class="text-sm text-zinc-500 mt-1">Signed client contracts created from approved proposals. New
                contracts are created from the Clients page.</p>
        </div>
    </div>

    
    <section class="w-full my-5">
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">

            <div class="contractStatusBtn max-md:col-span-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4 shadow-sm cursor-pointer"
                data-status="all">
                <div class="w-full py-1 rounded-full bg-blue-500"></div>
                <p class="text-xs text-zinc-400 font-semibold mt-2">ALL</p>
                <p class="text-2xl font-bold text-zinc-900 dark:text-zinc-100" id="countAll">0</p>
            </div>

            <div class="contractStatusBtn bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4 shadow-sm cursor-pointer"
                data-status="active">
                <div class="w-full py-1 rounded-full bg-green-500"></div>
                <p class="text-xs text-zinc-400 font-semibold mt-2">ACTIVE</p>
                <p class="text-2xl font-bold text-zinc-900 dark:text-zinc-100" id="countActive">0</p>
            </div>

            <div class="contractStatusBtn bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4 shadow-sm cursor-pointer"
                data-status="expiring">
                <div class="w-full py-1 rounded-full bg-amber-500"></div>
                <p class="text-xs text-zinc-400 font-semibold mt-2">EXPIRING</p>
                <p class="text-2xl font-bold text-zinc-900 dark:text-zinc-100" id="countExpiring">0</p>
            </div>

            <div class="contractStatusBtn bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4 shadow-sm cursor-pointer"
                data-status="expired">
                <div class="w-full py-1 rounded-full bg-red-500"></div>
                <p class="text-xs text-zinc-400 font-semibold mt-2">EXPIRED</p>
                <p class="text-2xl font-bold text-zinc-900 dark:text-zinc-100" id="countExpired">0</p>
            </div>

            <div class="contractStatusBtn bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4 shadow-sm cursor-pointer"
                data-status="terminated">
                <div class="w-full py-1 rounded-full bg-zinc-500"></div>
                <p class="text-xs text-zinc-400 font-semibold mt-2">TERMINATED</p>
                <p class="text-2xl font-bold text-zinc-900 dark:text-zinc-100" id="countTerminated">0</p>
            </div>

        </div>
    </section>

    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'tableClientContracts']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
</div>


<?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6a555649da86b3de44465cdfe004aa4 = $attributes; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'viewClientContractModal']); ?>
    <div class="p-5 border-b flex justify-between items-center">
        <div>
            <div class="flex items-center gap-2">
                <p class="text-lg font-semibold" id="vcContractCode">-</p>
                <span id="vcStatusBadge"></span>
            </div>
            <p class="text-xs text-zinc-400" id="vcClientName">-</p>
        </div>
        <button class="modal-close">✕</button>
    </div>

    <div class="max-h-[65vh] overflow-y-auto p-5 space-y-4 text-sm text-zinc-700">
        <div id="vcInfoContainer" class="grid grid-cols-2 gap-3 text-sm"></div>

        <div>
            <p class="font-semibold text-sm text-zinc-700 mb-2">Contracted Rates</p>
            <table class="min-w-full border border-zinc-200 rounded-lg text-xs">
                <thead class="bg-zinc-50">
                    <tr>
                        <th class="px-3 py-2 text-left text-zinc-500 uppercase">Route</th>
                        <th class="px-3 py-2 text-left text-zinc-500 uppercase">Container</th>
                        <th class="px-3 py-2 text-right text-zinc-500 uppercase">Base Rate</th>
                        <th class="px-3 py-2 text-right text-zinc-500 uppercase">Discount</th>
                        <th class="px-3 py-2 text-right text-zinc-500 uppercase">Final Rate</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-zinc-100" id="vcRatesBody"></tbody>
            </table>
        </div>

        <div id="vcTerminationInfo" class="hidden border-t pt-4 text-xs text-zinc-500 space-y-1"></div>
    </div>

    <div class="border-t px-5 py-4 space-y-2">
        <div class="flex justify-between items-center gap-2">
            <button type="button" id="vcTerminateBtn"
                class="hidden px-4 py-2 text-sm rounded-lg bg-red-600 hover:bg-red-700 text-white">
                Terminate Contract
            </button>
            <button type="button" id="vcApproveBtn"
                class="hidden px-4 py-2 text-sm rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white">
                Approve
            </button>
            <div class="flex justify-end gap-2 flex-1">
                <a href="#" id="vcDownloadBtn" target="_blank"
                    class="px-4 py-2 text-sm rounded-lg bg-orange-500 hover:bg-orange-600 text-white">
                    Download PDF
                </a>
                <button class="modal-close border px-4 py-2 rounded-lg text-sm">Close</button>
            </div>
        </div>

        <div id="vcTerminateReasonPanel" class="hidden pt-2 border-t border-zinc-100 space-y-2">
            <label class="block text-[11px] font-semibold text-zinc-500 uppercase">Termination Reason</label>
            <textarea id="vcTerminateReasonInput" rows="2" maxlength="500"
                class="w-full border rounded-lg px-2 py-1.5 text-sm dark:text-zinc-900"
                placeholder="Why is this contract being terminated?"></textarea>
            <div class="flex gap-2">
                <button type="button" id="vcTerminateConfirmBtn"
                    class="px-3 py-1.5 text-xs rounded-lg bg-red-600 hover:bg-red-700 text-white">Confirm
                    Termination</button>
                <button type="button" id="vcTerminateDismissBtn"
                    class="px-3 py-1.5 text-xs rounded-lg border">Nevermind</button>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $attributes = $__attributesOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__attributesOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>


<script>
    (function() {
        /**
         * Contracts page (SPA content-area script).
         *
         * Contracts are now created exclusively from the Clients page
         * (Client Master detail modal -> Proposals tab -> "Create Contract").
         * This page only lists ALL client contracts across ALL clients,
         * lets you filter by status, and view/download any one of them.
         */

        const CONTRACT_STATUS_MAPPING = {
            1: {
                label: 'Draft',
                classes: 'bg-zinc-100 text-zinc-600'
            },
            2: {
                label: 'Active',
                classes: 'bg-emerald-50 text-emerald-700'
            },
            3: {
                label: 'Expired',
                classes: 'bg-amber-50 text-amber-700'
            },
            4: {
                label: 'Terminated',
                classes: 'bg-red-50 text-red-700'
            },
        };

        let currentContractId = null;

        function statusBadge(status) {
            const meta = CONTRACT_STATUS_MAPPING[status] ?? {
                label: 'Unknown',
                classes: 'bg-zinc-100 text-zinc-500'
            };
            return `<span class="inline-flex items-center rounded-full ${meta.classes} px-2 py-0.5 text-xs font-medium">${meta.label}</span>`;
        }

        // -----------------------------------------------------------------
        // List
        // -----------------------------------------------------------------
        async function loadContracts() {
            const response = await apiCall({
                mode: 'GET',
                url: '/api/clientContracts',
            });

            if (!response.success) return;

            updateContractCounts(response.status_counts);
            renderTable().load(1);
        }

        function renderTable() {
            const thead = [{
                    title: "Code",
                    key: "code",
                },
                {
                    title: "Client",
                    key: "client.company_name",
                    render: (r) => r.client?.company_name ?? '-',
                },
                {
                    title: "Customer Code",
                    key: "client.customer_code",
                    render: (r) => r.client?.customer_code ?? '-',
                },
                {
                    title: "Source Proposal",
                    key: "proposal.code",
                    render: (r) => r.proposal?.code ?? '-',
                },
                {
                    title: "Valid From",
                    key: "valid_from",
                    render: (r) => r.valid_from ? formatDate(r.valid_from) : '-',
                },
                {
                    title: "Valid To",
                    key: "valid_to",
                    render: (r) => r.valid_to ? formatDate(r.valid_to) : '-',
                },
                {
                    title: "Status",
                    key: "status",
                    render: (r) => statusBadge(r.status),
                },
            ];

            const table = renderRemoteTable({
                url: '/api/clientContracts',
                tableId: "tableClientContracts",
                afterRenderFunction: handleClick,
                thead: thead,
            });

            return table;
        }

        function handleClick(row) {
            row.addEventListener("click", function() {
                const data = JSON.parse(row.dataset.row);
                openViewContract(data.id);
            });
        }

        document.querySelectorAll(".contractStatusBtn").forEach((btn) => {
            btn.addEventListener("click", function() {
                document
                    .querySelectorAll(".contractStatusBtn")
                    .forEach((card) => card.classList.remove("ring-2", "ring-orange-500",
                        "ring-blue-500"));

                this.classList.add("ring-2", "ring-orange-500");

                const status = this.dataset.status;
                renderTable().setFilter("status", status);
            });
        });

        // -----------------------------------------------------------------
        // View + download
        // -----------------------------------------------------------------
        async function openViewContract(id) {
            const response = await apiCall({
                mode: 'GET',
                url: `/api/clientContracts/${id}`
            });

            if (!response.success) {
                showMessage({
                    status: 'error',
                    title: 'Error',
                    message: 'Unable to load this contract.',
                });
                return;
            }

            const contract = response.data;
            currentContractId = contract.id;

            document.getElementById('vcContractCode').textContent = contract.code;
            document.getElementById('vcClientName').textContent =
                `${contract.client?.company_name ?? '-'} (${contract.client?.customer_code ?? '-'})`;
            document.getElementById('vcStatusBadge').innerHTML = statusBadge(contract.status);

            document.getElementById('vcInfoContainer').innerHTML = `
                <div><span class="text-zinc-400">Source Proposal:</span> <div class="font-medium">${contract.proposal?.code ?? '-'}</div></div>
                <div><span class="text-zinc-400">Prepared By:</span> <div class="font-medium">${contract.creator?.name ?? '-'}</div></div>
                <div><span class="text-zinc-400">Signed Date:</span> <div class="font-medium">${contract.signed_date ? formatDate(contract.signed_date) : '-'}</div></div>
                <div><span class="text-zinc-400">Valid From:</span> <div class="font-medium">${formatDate(contract.valid_from)}</div></div>
                <div><span class="text-zinc-400">Valid To:</span> <div class="font-medium">${formatDate(contract.valid_to)}</div></div>
            `;

            const rateRows = (contract.rates ?? []).map((r) => `
                <tr>
                    <td class="px-3 py-2">${r.origin_port ? (r.origin_port.location?.name ?? '-') + ' - ' + r.origin_port.name : '-'} &rarr; ${r.destination_port ? (r.destination_port.location?.name ?? '-') + ' - ' + r.destination_port.name : '-'}</td>
                    <td class="px-3 py-2">${r.container?.name ?? '-'} / ${r.container_class?.class ?? '-'} / ${r.container_size?.size ?? '-'}</td>
                    <td class="px-3 py-2 text-right">${Number(r.base_rate).toLocaleString()}</td>
                    <td class="px-3 py-2 text-right">${r.discount_type ? (r.discount_type === 'percentage' ? r.discount_value + '%' : Number(r.discount_value).toLocaleString()) : '-'}</td>
                    <td class="px-3 py-2 text-right font-semibold">${Number(r.final_rate).toLocaleString()}</td>
                </tr>
            `).join('');

            document.getElementById('vcRatesBody').innerHTML = rateRows ||
                '<tr><td colspan="5" class="px-3 py-4 text-center text-zinc-400">No rate lines.</td></tr>';

            document.getElementById('vcDownloadBtn').href = `/api/clientContracts/${contract.id}/pdf`;

            const terminationInfo = document.getElementById('vcTerminationInfo');
            if (contract.status === 4) {
                terminationInfo.innerHTML = `
                    <div><span class="text-zinc-400">Terminated By:</span> <span class="font-medium">${contract.terminator?.name ?? '-'}</span></div>
                    <div><span class="text-zinc-400">Terminated At:</span> <span class="font-medium">${formatDateTime(contract.terminated_at)}</span></div>
                    <div><span class="text-zinc-400">Reason:</span> <span class="font-medium">${contract.terminated_reason ?? '-'}</span></div>
                `;
                terminationInfo.classList.remove('hidden');
            } else {
                terminationInfo.classList.add('hidden');
            }

            document.getElementById('vcTerminateBtn').classList.toggle('hidden', contract.status !== 2);
            document.getElementById('vcApproveBtn').classList.toggle('hidden', !(contract.status === 1 &&
                contract.can_approve));
            document.getElementById('vcTerminateReasonPanel').classList.add('hidden');
            document.getElementById('vcTerminateReasonInput').value = '';

            initModal({
                modalId: 'viewClientContractModal'
            });
        }

        document.getElementById('vcTerminateBtn').addEventListener('click', function() {
            document.getElementById('vcTerminateReasonPanel').classList.remove('hidden');
            document.getElementById('vcTerminateReasonInput').focus();
        });

        document.getElementById('vcTerminateDismissBtn').addEventListener('click', function() {
            document.getElementById('vcTerminateReasonPanel').classList.add('hidden');
            document.getElementById('vcTerminateReasonInput').value = '';
        });

        document.getElementById('vcTerminateConfirmBtn').addEventListener('click', async function() {
            const reason = document.getElementById('vcTerminateReasonInput').value.trim();

            if (!reason) {
                document.getElementById('vcTerminateReasonInput').focus();
                return;
            }

            const response = await apiCall({
                mode: 'POST',
                isJson: true,
                payload: {
                    reason
                },
                url: `/api/clientContracts/${currentContractId}/terminate`,
                button: this,
            });

            if (!response.success) {
                showMessage({
                    status: 'error',
                    title: 'Unable to terminate contract',
                    message: response.message ?? '',
                });
                return;
            }

            showMessage({
                status: 'success',
                title: 'Contract terminated'
            });
            await openViewContract(currentContractId);
            renderTable().reload();
        });

        document.getElementById('vcApproveBtn').addEventListener('click', async function() {
            const response = await apiCall({
                mode: 'POST',
                isJson: true,
                payload: {},
                url: `/api/clientContracts/${currentContractId}/approve`,
                button: this,
            });

            if (!response.success) {
                showMessage({
                    status: 'error',
                    title: 'Unable to approve contract',
                    message: response.message ?? '',
                });
                return;
            }

            showMessage({
                status: 'success',
                title: 'Contract approved'
            });
            await openViewContract(currentContractId);
            renderTable().reload();
        });

        function updateContractCounts(counts) {
            document.getElementById("countAll").textContent = counts.all;
            document.getElementById("countActive").textContent = counts.active;
            document.getElementById("countExpiring").textContent = counts?.expiring ?? 0;
            document.getElementById("countExpired").textContent = counts.expired;
            document.getElementById("countTerminated").textContent = counts.terminated;
        }

        // -----------------------------------------------------------------
        // Init
        // -----------------------------------------------------------------
        function init() {
            loadContracts();

            if (window.contractsOpenId) {
                const openId = window.contractsOpenId;
                window.contractsOpenId = null;
                openViewContract(openId);
            }
        }

        init();
    })();
</script>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/pages/contracts.blade.php ENDPATH**/ ?>