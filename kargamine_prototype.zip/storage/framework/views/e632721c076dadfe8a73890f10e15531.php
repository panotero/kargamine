<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $navLayout = Auth::user()->nav_layout ?? 'side'; ?>
    <div class="flex h-screen bg-zinc-100 dark:bg-zinc-950" id="appShell" data-nav-layout="<?php echo e($navLayout); ?>"
        data-direct-page-link="<?php echo e($directPageLink ?? ''); ?>">
        <aside id="sidebar-wrapper"
            class="bg-white dark:bg-zinc-900 shadow-lg w-64
           fixed lg:static inset-y-0 left-0
           h-full flex flex-col
           transform -translate-x-full lg:translate-x-0
           transition-[width,transform] duration-300 ease-in-out
           overflow-hidden
           z-40
           <?php echo e($navLayout === 'top' ? 'lg:hidden' : ''); ?>">
            <div class="w-full p-5 text-zinc-900 dark:text-white flex items-center justify-between gap-2">
                <?php $__appInfo = \App\Models\AppInformationSetting::current(); ?>
                <div id="sidebar-brand" class="min-w-0 overflow-hidden whitespace-nowrap transition-opacity duration-150">
                    <?php if($__appInfo->logo_path): ?>
                        <img src="<?php echo e($__appInfo->logo_path); ?>" alt="<?php echo e($__appInfo->app_name); ?>" class="h-8 max-w-full object-contain">
                    <?php else: ?>
                        <h1 class="font-semibold text-sm"><?php echo e($__appInfo->app_name); ?></h1>
                    <?php endif; ?>
                    <h1 class="text-md md:text-md font-bold"></h1>
                </div>
                <button id="sidebar-collapse-toggle" type="button"
                    class="hidden lg:flex shrink-0 p-1.5 rounded-lg text-zinc-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-950/40 transition"
                    title="Collapse navigation">
                    <svg id="sidebar-collapse-icon" class="w-4 h-4 transition-transform duration-300" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
                    </svg>
                </button>
            </div>

            <div class="w-full flex flex-col justify-between flex-grow overflow-y-auto overflow-x-hidden">
                <nav id="sidebar-menu" class="p-4 space-y-2 font-semibold">
                </nav>

                
                <div class="p-4 border-t border-zinc-100 dark:border-zinc-800">
                    <button type="button" id="helpNavBtn"
                        class="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-semibold text-zinc-500 dark:text-zinc-400 hover:bg-orange-50 dark:hover:bg-orange-950/40 hover:text-orange-600 transition">
                        <svg class="w-5 h-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.5M12 17h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Help &amp; Documentation</span>
                    </button>
                </div>
            </div>
        </aside>

        <div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 hidden z-30 lg:hidden"></div>

        <div class="flex-1 flex flex-col min-w-0">
            <button id="sidebar-toggle"
                class="lg:hidden absolute top-2 left-2 px-2 py-4 bg-orange-500 text-white rounded z-10">
                ☰
            </button>
            <header
                class="bg-white dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800 shadow-sm dark:shadow-black/40 px-6 py-4 flex justify-between items-center">
                <h2 id="page-title" class="text-xl font-semibold text-zinc-900 dark:text-white max-lg:pl-5">
                    Dashboard
                </h2>

                <div class="flex items-center space-x-4">
                    <?php echo $__env->make('layouts.partials.notification-bell', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => 'w-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => 'w-auto']); ?>
                         <?php $__env->slot('trigger', null, []); ?> 
                            <button class="text-zinc-700 dark:text-zinc-200">
                                <div id="headerAvatarWrap" class="flex flex-col items-center justify-center">
                                    <?php if(Auth::user()->profile_photo_url): ?>
                                        <img src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="Avatar"
                                            class="h-10 w-10 rounded-full object-cover">
                                    <?php else: ?>
                                        <div
                                            class="h-10 w-10 rounded-full bg-orange-500 text-white flex items-center justify-center font-semibold">
                                            <?php echo e(strtoupper(substr(Auth::user()->name, 0, 1))); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                            </button>
                         <?php $__env->endSlot(); ?>
                         <?php $__env->slot('content', null, []); ?> 
                         <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
                </div>
            </header>
            <nav id="topnav-bar"
                class="<?php echo e($navLayout === 'top' ? 'hidden lg:flex' : 'hidden'); ?> items-center gap-1 bg-white dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800 px-4 py-2">
                <div class="flex items-center gap-2 pr-4 mr-2 border-r border-zinc-200 dark:border-zinc-800 shrink-0">
                    <?php if($__appInfo->logo_path): ?>
                        <img src="<?php echo e($__appInfo->logo_path); ?>" alt="<?php echo e($__appInfo->app_name); ?>" class="h-8 max-w-full object-contain">
                    <?php else: ?>
                        <h1 class="font-semibold text-sm text-zinc-900 dark:text-white whitespace-nowrap"><?php echo e($__appInfo->app_name); ?></h1>
                    <?php endif; ?>
                </div>
                <div id="topnav-menu" class="flex items-center gap-1 overflow-x-auto min-w-0"></div>
            </nav>
            <main id="content"
                class="flex-1 w-full overflow-y-auto bg-zinc-100 dark:bg-zinc-950 text-zinc-800 dark:text-zinc-200">
            </main>

        </div>
    </div>

    <script>
        document.getElementById('helpNavBtn').addEventListener('click', function() {
            loadPage({
                title: 'Help & Documentation',
                link: '/page_help'
            });
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/dashboard.blade.php ENDPATH**/ ?>