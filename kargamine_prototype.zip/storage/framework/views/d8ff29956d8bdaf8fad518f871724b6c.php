<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php $__appInfo = \App\Models\AppInformationSetting::current(); ?>
    <link rel="icon" href="<?php echo e($__appInfo->icon_path ?: '/favicon.ico?v=999'); ?>">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($__appInfo->app_name); ?></title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@glidejs/glide/dist/css/glide.core.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.5/css/dataTables.tailwindcss.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php
        $__theme = \App\Models\AppThemeSetting::current();
        // Tailwind's spacing/type scale is rem-based throughout, so scaling
        // the root font-size scales the whole UI proportionally - the same
        // technique used for the theme colors above, applied once here
        // instead of touching every page. Profile -> Font Size writes this
        // (see ProfileController::updateFontSize()); "medium" is Tailwind's
        // own default (16px = 1rem), left unset rather than redeclared.
        $__fontSizePx = ['small' => '14px', 'large' => '18px', 'extra_large' => '20px'][Auth::user()->font_size ?? 'medium'] ?? null;
    ?>
    <style>
        :root {
            <?php echo e(\App\Support\TailwindPalette::cssVariables('main', $__theme->main_color)); ?>

            <?php echo e(\App\Support\TailwindPalette::cssVariables('accent', $__theme->accent_color)); ?>

            <?php echo e(\App\Support\TailwindPalette::cssVariables('secondary', $__theme->button_secondary_color)); ?>

            <?php echo e(\App\Support\TailwindPalette::cssVariables('danger', $__theme->button_danger_color)); ?>

        }
        <?php if($__fontSizePx): ?>
        html {
            font-size: <?php echo e($__fontSizePx); ?>;
        }
        <?php endif; ?>
    </style>
</head>

<body class="font-sans antialiased [&_*]:duration-300">
    <div class="min-h-screen bg-gray-100 dark:bg-gray-900  max-md:max-w-screen">
        <?php if(isset($header)): ?>
            <header class="bg-white dark:bg-zinc-700 shadow">
                <div class="max-w-screen mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <?php echo e($header); ?>

                </div>

            </header>
        <?php endif; ?>
        <main>
            <?php echo e($slot); ?>

        </main>

    </div>
    <?php if (isset($component)) { $__componentOriginalec8f3a28e5351ecf32e2d02b9ba361a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalec8f3a28e5351ecf32e2d02b9ba361a6 = $attributes; } ?>
<?php $component = App\View\Components\CustomMessage::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('custom-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CustomMessage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalec8f3a28e5351ecf32e2d02b9ba361a6)): ?>
<?php $attributes = $__attributesOriginalec8f3a28e5351ecf32e2d02b9ba361a6; ?>
<?php unset($__attributesOriginalec8f3a28e5351ecf32e2d02b9ba361a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec8f3a28e5351ecf32e2d02b9ba361a6)): ?>
<?php $component = $__componentOriginalec8f3a28e5351ecf32e2d02b9ba361a6; ?>
<?php unset($__componentOriginalec8f3a28e5351ecf32e2d02b9ba361a6); ?>
<?php endif; ?>
    <div id="globalMessageContainer"
        class="fixed top-0 left-1/2 -translate-x-1/2 mt-10 z-50 flex flex-col items-center pointer-events-none">
    </div>
    

    <script src="https://cdn.jsdelivr.net/npm/@glidejs/glide/dist/glide.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/2.3.5/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.3.5/js/dataTables.tailwindcss.js"></script>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/layouts/app.blade.php ENDPATH**/ ?>