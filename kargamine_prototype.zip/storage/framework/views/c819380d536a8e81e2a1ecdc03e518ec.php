
<?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6a555649da86b3de44465cdfe004aa4 = $attributes; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'ProspectInfoModal','overlay-padding' => 'p-0 md:p-4','class' => 'rounded-none md:rounded-2xl md:min-w-[85vw] md:max-w-[95vw] h-full flex flex-col md:h-auto md:min-h-[82vh] md:max-h-[92vh]']); ?>

    
    <div class="px-5 py-4 border-b border-zinc-200 dark:border-zinc-800 flex justify-between items-center">
        <div>
            <p class="text-lg font-semibold text-zinc-900 dark:text-white" id="pimTitle">Prospect</p>
            <p class="text-xs text-zinc-400 dark:text-zinc-500" id="pimSubtitle"></p>
        </div>
        <button
            class="modal-close text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 w-8 h-8 flex items-center justify-center rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800">
            ✕
        </button>
    </div>

    <div class="flex flex-col md:flex-row gap-5 p-5 flex-1 overflow-y-auto">

        
        <div class="flex-1 min-w-0">

            <div class="flex items-center gap-1 border-b border-zinc-200 dark:border-zinc-700 mb-4" id="pimTabBar">
                <button type="button" id="pimTabBtnLocations" data-pim-tab="Locations"
                    class="pim-tab-btn px-3 py-2 text-sm font-medium border-b-2 -mb-px border-orange-500 text-orange-600 dark:text-orange-400">
                    Locations
                </button>
                <button type="button" id="pimTabBtnContacts" data-pim-tab="Contacts"
                    class="pim-tab-btn px-3 py-2 text-sm font-medium border-b-2 -mb-px border-transparent text-zinc-500 dark:text-zinc-400">
                    Contacts
                </button>
                <button type="button" id="pimTabBtnRequirements" data-pim-tab="Requirements"
                    class="pim-tab-btn px-3 py-2 text-sm font-medium border-b-2 -mb-px border-transparent text-zinc-500 dark:text-zinc-400">
                    Requirements
                </button>
                <button type="button" id="pimTabBtnOriginDestination" data-pim-tab="OriginDestination"
                    class="pim-tab-btn hidden px-3 py-2 text-sm font-medium border-b-2 -mb-px border-transparent text-zinc-500 dark:text-zinc-400">
                    Origin &amp; Destination
                </button>
            </div>

            
            <div class="pim-tab-pane space-y-3" data-pim-pane="Locations">
                <div class="flex justify-end">
                    <button type="button" id="pimAddLocationBtn"
                        class="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200">
                        + Add Location
                    </button>
                </div>
                <div id="pimLocationsSummary" class="space-y-2"></div>
            </div>

            
            <div class="pim-tab-pane hidden space-y-3" data-pim-pane="Contacts">
                <div class="flex justify-end">
                    <button type="button" id="pimAddContactBtn"
                        class="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200">
                        + Add Contact
                    </button>
                </div>
                <div id="pimContactsSummary" class="space-y-4"></div>
            </div>

            
            <div class="pim-tab-pane hidden space-y-6" data-pim-pane="Requirements">

                
                <div id="pimContainersTableWrap" class="space-y-2">
                    <div class="flex justify-between items-center">
                        <p class="text-[11px] font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">
                            Freights</p>
                        <button type="button" id="pimAddFreightBtn"
                            class="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200">
                            + Add Freight
                        </button>
                    </div>
                    <div class="overflow-x-auto border border-zinc-200 dark:border-zinc-700 rounded-xl">
                        <table class="min-w-full text-xs">
                            <thead
                                class="bg-zinc-50 dark:bg-zinc-800/50 text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">
                                <tr>
                                    <th class="px-3 py-2 text-left">Type</th>
                                    <th class="px-3 py-2 text-left">Size</th>
                                    <th class="px-3 py-2 text-left">Min Temp</th>
                                    <th class="px-3 py-2 text-left">Revenue Ton (RT)</th>
                                    <th class="px-3 py-2 text-left">Cargo Measurement</th>
                                    <th class="px-3 py-2 text-left">Qty</th>
                                    <th class="px-3 py-2 text-left">Frequency</th>
                                    <th class="px-3 py-2 text-left">Service Type</th>
                                    <th class="px-3 py-2 text-left">Origin</th>
                                    <th class="px-3 py-2 text-left">Destination</th>
                                    <th class="px-3 py-2 text-left">Declared Value</th>
                                    <th class="px-3 py-2 text-left">Weight</th>
                                    <th class="px-3 py-2 text-left">Cargo Type</th>
                                    <th class="px-3 py-2 text-left">Cargo Description</th>
                                    <th class="px-3 py-2 text-left">Special Requirements</th>
                                    <th class="px-3 py-2 text-left">Booking Unit Type</th>
                                    <th class="px-3 py-2 text-left">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="pimContainersTableBody" class="divide-y divide-zinc-100 dark:divide-zinc-700">
                            </tbody>
                        </table>
                    </div>
                </div>

                
                <div id="pimTruckingsTableWrap" class="space-y-2">
                    <div class="flex justify-between items-center">
                        <p class="text-[11px] font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">
                            Truckings</p>
                        <button type="button" id="pimAddTruckingBtn"
                            class="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200">
                            + Add Trucking
                        </button>
                    </div>
                    <div class="overflow-x-auto border border-zinc-200 dark:border-zinc-700 rounded-xl">
                        <table class="min-w-full text-xs">
                            <thead
                                class="bg-zinc-50 dark:bg-zinc-800/50 text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">
                                <tr>
                                    <th class="px-3 py-2 text-left">Trucking Cargo Type</th>
                                    <th class="px-3 py-2 text-left">Qty</th>
                                    <th class="px-3 py-2 text-left">Frequency</th>
                                    <th class="px-3 py-2 text-left">Dispatch Mode</th>
                                    <th class="px-3 py-2 text-left">Origin</th>
                                    <th class="px-3 py-2 text-left">Destination</th>
                                    <th class="px-3 py-2 text-left">Declared Value</th>
                                    <th class="px-3 py-2 text-left">Weight</th>
                                    <th class="px-3 py-2 text-left">Cargo Type</th>
                                    <th class="px-3 py-2 text-left">Cargo Description</th>
                                    <th class="px-3 py-2 text-left">Special Requirements</th>
                                    <th class="px-3 py-2 text-left">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="pimTruckingsTableBody" class="divide-y divide-zinc-100 dark:divide-zinc-700">
                            </tbody>
                        </table>
                    </div>
                </div>

                
                <div id="pimChartersTableWrap" class="space-y-2">
                    <div class="flex justify-between items-center">
                        <p class="text-[11px] font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">
                            Charters</p>
                        <button type="button" id="pimAddCharterBtn"
                            class="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200">
                            + Add Charter
                        </button>
                    </div>
                    <div class="overflow-x-auto border border-zinc-200 dark:border-zinc-700 rounded-xl">
                        <table class="min-w-full text-xs">
                            <thead
                                class="bg-zinc-50 dark:bg-zinc-800/50 text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">
                                <tr>
                                    <th class="px-3 py-2 text-left">Cargo</th>
                                    <th class="px-3 py-2 text-left">Ports</th>
                                    <th class="px-3 py-2 text-left">Start Date</th>
                                    <th class="px-3 py-2 text-left">End Date</th>
                                    <th class="px-3 py-2 text-left">Declared Value</th>
                                    <th class="px-3 py-2 text-left">Weight</th>
                                    <th class="px-3 py-2 text-left">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="pimChartersTableBody" class="divide-y divide-zinc-100 dark:divide-zinc-700">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <div class="pim-tab-pane hidden space-y-3" data-pim-pane="OriginDestination">
                <div class="flex justify-end">
                    <button type="button" id="pimAddOdBtn"
                        class="text-xs px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200">
                        + Add Origin/Destination
                    </button>
                </div>
                <div class="overflow-x-auto border border-zinc-200 dark:border-zinc-700 rounded-xl">
                    <table class="min-w-full text-xs">
                        <thead
                            class="bg-zinc-50 dark:bg-zinc-800/50 text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">
                            <tr>
                                <th class="px-3 py-2 text-left">Location Type</th>
                                <th class="px-3 py-2 text-left">No./Unit No.</th>
                                <th class="px-3 py-2 text-left">Building</th>
                                <th class="px-3 py-2 text-left">Street</th>
                                <th class="px-3 py-2 text-left">Country</th>
                                <th class="px-3 py-2 text-left">Province</th>
                                <th class="px-3 py-2 text-left">Town/City</th>
                                <th class="px-3 py-2 text-left">Barangay</th>
                                <th class="px-3 py-2 text-left">Postal Code</th>
                                <th class="px-3 py-2 text-left">Location Mnemonic</th>
                                <th class="px-3 py-2 text-left">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="pimOdTableBody" class="divide-y divide-zinc-100 dark:divide-zinc-700"></tbody>
                    </table>
                </div>
            </div>

        </div>

        
        <div class="w-full md:w-[19rem] shrink-0 space-y-3" id="pimContactSummary">
            <div class="flex justify-between items-center">
                <p class="text-[11px] font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">Contact
                    Summary</p>
                <button type="button" id="pimSummaryEditBtn"
                    class="text-xs font-medium text-orange-600 hover:text-orange-700 dark:text-orange-400 dark:hover:text-orange-300">Edit</button>
            </div>

            
            <div id="pimIdentitySummary" class="space-y-3"></div>

            
            <div id="pimIdentityEditForm" class="hidden space-y-3">
                <div>
                    <label for="pimEditSource"
                        class="text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Prospect
                        Source</label>
                    <select id="pimEditSource"
                        class="w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-2 py-1.5 text-sm mt-1">
                        <option value="Cold Call">Cold Call</option>
                        <option value="Referral">Referral</option>
                        <option value="Social Media">Social Media</option>
                        <option value="Walk-In">Walk-In</option>
                        <option value="Others">Others</option>
                    </select>
                </div>
                <div>
                    <label for="pimEditCompanyName"
                        class="text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Prospect
                        Name</label>
                    <input type="text" id="pimEditCompanyName"
                        class="w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-2 py-1.5 text-sm mt-1">
                </div>
                <div>
                    <label for="pimEditTypeOfBusiness"
                        class="text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Business
                        Type</label>
                    <select id="pimEditTypeOfBusiness"
                        class="pimEditTypeOfBusinessDropdown w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-2 py-1.5 text-sm mt-1">
                        <option value="">Select Business Type</option>
                    </select>
                </div>
                <div class="flex justify-end gap-2 pt-2">
                    <button type="button" id="pimSummaryCancelBtn"
                        class="text-sm px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-200 font-medium hover:bg-zinc-50 dark:hover:bg-zinc-800">
                        Cancel
                    </button>
                    <button type="button" id="pimSummarySaveBtn" disabled
                        class="text-sm px-3 py-1.5 rounded-lg bg-orange-500 text-white font-medium disabled:opacity-40 disabled:cursor-not-allowed">
                        Save
                    </button>
                </div>
            </div>

            
            <div class="border-t dark:border-zinc-700 pt-3 space-y-1.5">
                <button type="button" id="pimRequestProposalBtn"
                    class="w-full justify-center bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-orange-500">
                    Request for Proposal
                </button>
                <p id="pimRequestProposalHint" class="hidden text-xs text-zinc-400 dark:text-zinc-500 text-center">
                    Awaiting CSR assignment from Management
                </p>
            </div>

            
            <div class="border-t dark:border-zinc-700 pt-3 space-y-2">
                <p class="text-[11px] font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">
                    Requested Proposals</p>
                <div id="pimRequestedProposals" tabindex="0" role="region" aria-label="Requested proposals"
                    class="space-y-2 max-h-64 overflow-y-auto focus:outline-none focus:ring-2 focus:ring-orange-500 rounded-lg">
                </div>
            </div>

            <div class="border-t dark:border-zinc-700 pt-3 space-y-2">
                <p class="text-[11px] font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">
                    Activity &amp; History</p>
                <div id="pimActivityTimeline" tabindex="0" role="region" aria-label="Activity history"
                    class="space-y-0 max-h-64 overflow-y-auto focus:outline-none focus:ring-2 focus:ring-orange-500 rounded-lg">
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $attributes = $__attributesOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__attributesOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalfa160e1bc661687a1dd4d579bd655ff1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfa160e1bc661687a1dd4d579bd655ff1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.add-location-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add-location-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfa160e1bc661687a1dd4d579bd655ff1)): ?>
<?php $attributes = $__attributesOriginalfa160e1bc661687a1dd4d579bd655ff1; ?>
<?php unset($__attributesOriginalfa160e1bc661687a1dd4d579bd655ff1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfa160e1bc661687a1dd4d579bd655ff1)): ?>
<?php $component = $__componentOriginalfa160e1bc661687a1dd4d579bd655ff1; ?>
<?php unset($__componentOriginalfa160e1bc661687a1dd4d579bd655ff1); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc281278ba514237b3c04e0a45c628257 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc281278ba514237b3c04e0a45c628257 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.add-contact-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add-contact-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc281278ba514237b3c04e0a45c628257)): ?>
<?php $attributes = $__attributesOriginalc281278ba514237b3c04e0a45c628257; ?>
<?php unset($__attributesOriginalc281278ba514237b3c04e0a45c628257); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc281278ba514237b3c04e0a45c628257)): ?>
<?php $component = $__componentOriginalc281278ba514237b3c04e0a45c628257; ?>
<?php unset($__componentOriginalc281278ba514237b3c04e0a45c628257); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginaled4e216c515bc7d8a4b64924b87311aa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled4e216c515bc7d8a4b64924b87311aa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pim-add-freight-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pim-add-freight-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled4e216c515bc7d8a4b64924b87311aa)): ?>
<?php $attributes = $__attributesOriginaled4e216c515bc7d8a4b64924b87311aa; ?>
<?php unset($__attributesOriginaled4e216c515bc7d8a4b64924b87311aa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled4e216c515bc7d8a4b64924b87311aa)): ?>
<?php $component = $__componentOriginaled4e216c515bc7d8a4b64924b87311aa; ?>
<?php unset($__componentOriginaled4e216c515bc7d8a4b64924b87311aa); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal954e703e844b8cdde5ec32bcdb5e71f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal954e703e844b8cdde5ec32bcdb5e71f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pim-add-trucking-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pim-add-trucking-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal954e703e844b8cdde5ec32bcdb5e71f3)): ?>
<?php $attributes = $__attributesOriginal954e703e844b8cdde5ec32bcdb5e71f3; ?>
<?php unset($__attributesOriginal954e703e844b8cdde5ec32bcdb5e71f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal954e703e844b8cdde5ec32bcdb5e71f3)): ?>
<?php $component = $__componentOriginal954e703e844b8cdde5ec32bcdb5e71f3; ?>
<?php unset($__componentOriginal954e703e844b8cdde5ec32bcdb5e71f3); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginale654bd4c69ded7a475258f2f23110510 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale654bd4c69ded7a475258f2f23110510 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pim-add-charter-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pim-add-charter-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale654bd4c69ded7a475258f2f23110510)): ?>
<?php $attributes = $__attributesOriginale654bd4c69ded7a475258f2f23110510; ?>
<?php unset($__attributesOriginale654bd4c69ded7a475258f2f23110510); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale654bd4c69ded7a475258f2f23110510)): ?>
<?php $component = $__componentOriginale654bd4c69ded7a475258f2f23110510; ?>
<?php unset($__componentOriginale654bd4c69ded7a475258f2f23110510); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal475d4401351a22737b540db8541a6ec4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal475d4401351a22737b540db8541a6ec4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.add-origin-destination-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add-origin-destination-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal475d4401351a22737b540db8541a6ec4)): ?>
<?php $attributes = $__attributesOriginal475d4401351a22737b540db8541a6ec4; ?>
<?php unset($__attributesOriginal475d4401351a22737b540db8541a6ec4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal475d4401351a22737b540db8541a6ec4)): ?>
<?php $component = $__componentOriginal475d4401351a22737b540db8541a6ec4; ?>
<?php unset($__componentOriginal475d4401351a22737b540db8541a6ec4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/components/prospect-info-modal.blade.php ENDPATH**/ ?>