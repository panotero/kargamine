
<?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6a555649da86b3de44465cdfe004aa4 = $attributes; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'CharterPortsModal','min-width' => 'lg:min-w-[60vw]','max-width' => 'lg:max-w-4xl']); ?>
    <div class="px-5 py-4 border-b border-zinc-200 dark:border-zinc-800 flex justify-between items-center">
        <p class="text-lg font-semibold text-zinc-900 dark:text-white">Charter Ports</p>
        <button class="modal-close text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 w-8 h-8 flex items-center justify-center rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800">
            ✕
        </button>
    </div>
    <div class="p-5 space-y-4">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
                <label for="cpmPort" class="text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Port Name</label>
                <select id="cpmPort"
                    class="cpmPortDropdown w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-3 py-2 text-sm mt-1">
                    <option value="">Select Port</option>
                </select>
            </div>
            <div>
                <label for="cpmPortChargeAccount" class="text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Port Charges Account</label>
                <select id="cpmPortChargeAccount"
                    class="w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-3 py-2 text-sm mt-1">
                    <option value="direct">Direct Payment by Charterer/Shipper/Cargo Owner</option>
                    <option value="invoice">Invoice to Charterer/Shipper/Cargo Owner</option>
                </select>
            </div>
            <div>
                <label for="cpmPortChargeAmount" class="text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Amount to be Charged</label>
                <input type="text" inputmode="decimal" id="cpmPortChargeAmount"
                    class="currency-input w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-3 py-2 text-sm mt-1 disabled:opacity-40 disabled:cursor-not-allowed disabled:bg-zinc-100 dark:disabled:bg-zinc-900">
            </div>

            <div class="md:col-span-3 border-t dark:border-zinc-700 pt-3">
                <p class="text-[11px] font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">Cargoes for Loading</p>
            </div>
            <div>
                <label for="cpmCargoesLoading" class="text-[11px] text-zinc-400 uppercase">Cargoes for Loading</label>
                <input type="text" inputmode="numeric" id="cpmCargoesLoading"
                    class="currency-input w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-3 py-2 text-sm mt-1 disabled:opacity-40 disabled:cursor-not-allowed disabled:bg-zinc-100 dark:disabled:bg-zinc-900">
            </div>
            <div>
                <label for="cpmMeasurementLoading" class="text-[11px] text-zinc-400 uppercase">Cargo Measurement</label>
                <input type="text" id="cpmMeasurementLoading"
                    class="w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-3 py-2 text-sm mt-1 disabled:opacity-40 disabled:cursor-not-allowed disabled:bg-zinc-100 dark:disabled:bg-zinc-900">
            </div>
            <div>
                <label for="cpmRtUnitLoading" class="text-[11px] text-zinc-400 uppercase">Revenue Ton Unit</label>
                <select id="cpmRtUnitLoading"
                    class="cpmRtUnitDropdown w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-3 py-2 text-sm mt-1 disabled:opacity-40 disabled:cursor-not-allowed disabled:bg-zinc-100 dark:disabled:bg-zinc-900"></select>
            </div>

            <div class="md:col-span-3 border-t dark:border-zinc-700 pt-3">
                <p class="text-[11px] font-semibold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">Cargoes for Unloading</p>
            </div>
            <div>
                <label for="cpmCargoesUnloading" class="text-[11px] text-zinc-400 uppercase">Cargoes for Unloading</label>
                <input type="text" inputmode="numeric" id="cpmCargoesUnloading"
                    class="currency-input w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-3 py-2 text-sm mt-1 disabled:opacity-40 disabled:cursor-not-allowed disabled:bg-zinc-100 dark:disabled:bg-zinc-900">
            </div>
            <div>
                <label for="cpmMeasurementUnloading" class="text-[11px] text-zinc-400 uppercase">Cargo Measurement</label>
                <input type="text" id="cpmMeasurementUnloading"
                    class="w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-3 py-2 text-sm mt-1 disabled:opacity-40 disabled:cursor-not-allowed disabled:bg-zinc-100 dark:disabled:bg-zinc-900">
            </div>
            <div>
                <label for="cpmRtUnitUnloading" class="text-[11px] text-zinc-400 uppercase">Revenue Ton Unit</label>
                <select id="cpmRtUnitUnloading"
                    class="cpmRtUnitDropdown w-full border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg px-3 py-2 text-sm mt-1 disabled:opacity-40 disabled:cursor-not-allowed disabled:bg-zinc-100 dark:disabled:bg-zinc-900"></select>
            </div>
        </div>

        <div class="flex justify-end">
            <button type="button" id="cpmAddBtn"
                class="text-sm px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-medium">
                + Add Port
            </button>
        </div>

        <div class="border-t dark:border-zinc-700 pt-3 space-y-2">
            <p id="cpmEmpty" class="hidden text-sm text-zinc-400 dark:text-zinc-500">No ports added yet.</p>
            <div id="cpmList" class="space-y-2"></div>
        </div>

        <div class="flex justify-end pt-2">
            <button type="button" id="cpmCloseBtn"
                class="text-sm px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-200 font-medium hover:bg-zinc-50 dark:hover:bg-zinc-800">
                Close
            </button>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $attributes = $__attributesOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__attributesOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/components/charter-ports-modal.blade.php ENDPATH**/ ?>