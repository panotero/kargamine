
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['maxWidth' => null, 'minWidth' => null, 'panelClass' => '', 'overlayPadding' => 'px-4', 'rounded' => null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['maxWidth' => null, 'minWidth' => null, 'panelClass' => '', 'overlayPadding' => 'px-4', 'rounded' => null]); ?>
<?php foreach (array_filter((['maxWidth' => null, 'minWidth' => null, 'panelClass' => '', 'overlayPadding' => 'px-4', 'rounded' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    $hasCustomClass = $attributes->has('class');
    $roundedClass = $rounded ?? ($hasCustomClass ? '' : 'rounded-2xl');
    $minWidthClass = $minWidth ?? ($hasCustomClass ? '' : 'lg:min-w-[40vw]');
    $maxWidthClass = $maxWidth ?? ($hasCustomClass ? '' : 'lg:max-w-[60vw]');
?>
<div id="<?php echo e($attributes->get('id', 'defaultModal')); ?>"
    class="fixed inset-0 hidden z-40 flex items-center justify-center bg-black/50 <?php echo e($overlayPadding); ?> modal">
    <div <?php echo e($attributes->except('id')->merge(['class' => "bg-white dark:bg-zinc-800 {$roundedClass} shadow-2xl w-full {$minWidthClass} {$maxWidthClass} {$panelClass}"])); ?>>
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/components/modal.blade.php ENDPATH**/ ?>