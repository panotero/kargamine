
<div class="container mx-auto p-3">

    <div class="flex justify-between items-center mb-5 p-2">
        <div>
            <h1 class="text-2xl font-bold">Proposals</h1>
            <p class="text-zinc-500">Review, approve, and track client proposals</p>
        </div>
        <div class="text-right">
            <p class="text-[11px] font-medium uppercase tracking-widest text-zinc-400">Awaiting Your Decision</p>
            <p class="text-2xl font-bold text-zinc-900 dark:text-zinc-100" id="countAwaitingDecision">0</p>
        </div>
    </div>

    
    <section class="w-full my-5">
        <div class="flex items-center flex-wrap gap-2">
            <div class="proposalStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 border-dashed border-zinc-300 text-zinc-500 dark:border-zinc-600 dark:text-zinc-400"
                data-status="all">
                <span>All</span>
                <span id="countAll">0</span>
            </div>
            <div class="proposalStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 text-amber-600 border-amber-300 dark:text-amber-400 dark:border-amber-700"
                data-status="1">
                <span>Pending RM</span>
                <span id="countPending">0</span>
            </div>
            <span class="text-zinc-300 dark:text-zinc-600">→</span>
            <div class="proposalStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 text-amber-600 border-amber-300 dark:text-amber-400 dark:border-amber-700"
                data-status="7">
                <span>Pending Manager</span>
                <span id="countPendingManager">0</span>
            </div>
            <span class="text-zinc-300 dark:text-zinc-600">→</span>
            <div class="proposalStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 text-green-600 border-green-300 dark:text-green-400 dark:border-green-700"
                data-status="2">
                <span>Approved</span>
                <span id="countApproved">0</span>
            </div>
            <span class="text-zinc-300 dark:text-zinc-600">→</span>
            <div class="proposalStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 text-blue-600 border-blue-300 dark:text-blue-400 dark:border-blue-700"
                data-status="4">
                <span>Accepted</span>
                <span id="countAccepted">0</span>
            </div>
            <div class="proposalStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 border-dashed text-red-600 border-red-300 dark:text-red-400 dark:border-red-700"
                data-status="3">
                <span>Disapproved</span>
                <span id="countDisapproved">0</span>
            </div>
            <div class="w-px h-6 bg-zinc-200 dark:bg-zinc-700"></div>
            <div class="proposalStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 border-dashed text-zinc-500 border-zinc-300 dark:text-zinc-400 dark:border-zinc-600"
                data-status="5">
                <span>Rejected</span>
                <span id="countRejected">0</span>
            </div>
            <div class="proposalStatusBtn cursor-pointer border rounded-full px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 border-dashed text-zinc-500 border-zinc-300 dark:text-zinc-400 dark:border-zinc-600"
                data-status="6">
                <span>Cancelled</span>
                <span id="countCancelled">0</span>
            </div>
        </div>
    </section>

    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'tableClientProposals']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
</div>


<?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6a555649da86b3de44465cdfe004aa4 = $attributes; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'ClientProposalModal']); ?>
    <div class="p-5 border-b flex justify-between items-center">
        <div>
            <div class="flex items-center gap-2">
                <p class="text-lg font-semibold" id="cpmCode">-</p>
                <span id="cpmStatusBadge"></span>
            </div>
            <p class="text-xs text-zinc-400" id="cpmClientName">-</p>
        </div>
        <button class="modal-close">✕</button>
    </div>

    <div class="max-h-[65vh] overflow-y-auto p-5 space-y-5">

        <div id="cpmDecisionInfo" class="text-xs text-zinc-500 hidden"></div>

        
        <div id="cpmLeadInfo" class="border rounded-lg p-3 hidden">
            <div class="flex items-center gap-2 mb-2">
                <p class="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest">Lead Information</p>
                <span id="cpmLeadInfoTag"
                    class="hidden text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400">
                    Lead-Scoped &middot; No Client Master Yet
                </span>
            </div>
            <div class="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
                <div><span class="text-zinc-400">Contact:</span> <span id="cpmLeadContact" class="font-medium">-</span></div>
                <div><span class="text-zinc-400">Company:</span> <span id="cpmLeadCompany" class="font-medium">-</span></div>
                <div><span class="text-zinc-400">Mobile:</span> <span id="cpmLeadMobile" class="font-medium">-</span></div>
                <div><span class="text-zinc-400">Email:</span> <span id="cpmLeadEmail" class="font-medium">-</span></div>
                <div><span class="text-zinc-400">Source:</span> <span id="cpmLeadSource" class="font-medium">-</span></div>
                <div><span class="text-zinc-400">Assigned To:</span> <span id="cpmLeadAssignedTo" class="font-medium">-</span></div>
            </div>
        </div>

        
        <table id="cpmLegacyRatesTable" class="w-full text-xs">
            <thead class="text-zinc-400 uppercase">
                <tr>
                    <th class="text-left py-1">Route</th>
                    <th class="text-left py-1">Container</th>
                    <th class="text-right py-1">Min Qty</th>
                    <th class="text-right py-1">Base Rate</th>
                    <th class="text-right py-1">Adjustment</th>
                    <th class="text-right py-1">Final Rate</th>
                </tr>
            </thead>
            <tbody id="cpmRatesBody"></tbody>
        </table>

        
        <table id="cpmRfpRatesTable" class="w-full text-xs hidden">
            <thead class="text-zinc-400 uppercase">
                <tr>
                    <th class="text-left py-1">Item No.</th>
                    <th class="text-left py-1">Product</th>
                    <th class="text-right py-1">Base Rate</th>
                    <th class="text-right py-1">Adjustment</th>
                    <th class="text-right py-1">Total</th>
                </tr>
            </thead>
            <tbody id="cpmRfpRatesBody"></tbody>
        </table>

        
        <div id="cpmAdditionalCharges" class="hidden">
            <p class="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest mb-1.5">Additional Charges</p>
            <div class="flex flex-wrap gap-1.5"></div>
        </div>

        
        <div id="cpmRfpTerms" class="hidden space-y-4">
            <div id="cpmRfpTermsOfPayment" class="hidden space-y-2">
                <p class="text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Terms of Payment</p>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div id="cpmRfpTopStandardWrap" class="hidden border border-zinc-200 dark:border-zinc-700 rounded-xl p-3">
                        <p class="text-[11px] font-semibold text-zinc-400 dark:text-zinc-500 mb-1">All Except Charter</p>
                        <p id="cpmRfpTopStandard" class="text-sm font-medium text-zinc-800 dark:text-zinc-100">-</p>
                    </div>
                    <div id="cpmRfpTopCharterWrap" class="hidden border border-zinc-200 dark:border-zinc-700 rounded-xl p-3">
                        <p class="text-[11px] font-semibold text-zinc-400 dark:text-zinc-500 mb-1">Charter Only</p>
                        <p id="cpmRfpTopCharter" class="text-sm font-medium text-zinc-800 dark:text-zinc-100">-</p>
                    </div>
                </div>
            </div>

            <div id="cpmRfpAncillaryWrap" class="hidden space-y-2">
                <p class="text-[11px] font-medium uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Ancillary Service Fees</p>
                <div id="cpmRfpAncillaryBody" class="space-y-3"></div>
            </div>
        </div>
    </div>

    
    <div class="border-t px-5 py-4 flex justify-end items-center gap-2">
        <div class="flex items-center gap-2">
            <button id="cpmCancelBtn"
                class="hidden px-4 py-2 text-sm rounded-lg border border-zinc-300 text-zinc-600 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-400 dark:hover:bg-zinc-800">Cancel Proposal</button>
            <button id="cpmDisapproveBtn"
                class="hidden px-4 py-2 text-sm rounded-lg border border-amber-400 text-amber-600 hover:bg-amber-50 dark:border-amber-700 dark:text-amber-400 dark:hover:bg-amber-950/30">Disapprove</button>
            <button id="cpmApproveBtn"
                class="hidden px-4 py-2 text-sm rounded-lg bg-green-600 hover:bg-green-700 text-white">Approve</button>
            <div class="w-px h-6 bg-zinc-200 dark:bg-zinc-700"></div>
            <button id="cpmRejectBtn"
                class="hidden px-4 py-2 text-sm rounded-lg bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-950/30 dark:text-red-400 dark:hover:bg-red-950/50">Reject</button>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $attributes = $__attributesOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__attributesOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>

<script>
    (function () {
        window.PROPOSALS_PAGE_MODE = 'approvals';
        window.initClientProposalsPage?.();
    })();
</script>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/pages/proposals.blade.php ENDPATH**/ ?>