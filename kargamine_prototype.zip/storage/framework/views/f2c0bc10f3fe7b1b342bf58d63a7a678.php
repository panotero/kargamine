<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['panelClass' => 'w-full md:w-[500px] lg:w-[700px]']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['panelClass' => 'w-full md:w-[500px] lg:w-[700px]']); ?>
<?php foreach (array_filter((['panelClass' => 'w-full md:w-[500px] lg:w-[700px]']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div
    <?php echo e($attributes->merge([
        'id' => 'defaultSideModal',
        'class' => 'fixed inset-0 hidden z-50 bg-black/50 side-modal',
    ])); ?>>

    <div
        class="side-modal-panel absolute top-0 right-0 h-screen <?php echo e($panelClass); ?> bg-white dark:bg-zinc-800 shadow-2xl translate-x-full transition-transform duration-300 ease-in-out overflow-y-auto">

        <?php echo e($slot); ?>


    </div>

</div>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/components/side-modal.blade.php ENDPATH**/ ?>