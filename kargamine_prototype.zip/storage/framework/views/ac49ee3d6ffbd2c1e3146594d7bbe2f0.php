<div class="container mx-auto p-3">

    <div class="flex justify-between items-center mb-5 p-2">

        <div>
            <h1 class="text-2xl font-bold">CRM Leads</h1>
            <p class="text-zinc-500">
                Manage leads and sales opportunities
                <span id="crmScopeIndicator" class="hidden"></span>
            </p>
        </div>

        <div class="flex items-center gap-6">
            <div class="text-right">
                <p class="text-[11px] font-medium uppercase tracking-widest text-zinc-400">Total</p>
                <p class="text-xl font-bold text-zinc-800 dark:text-zinc-100" id="crmTotalStat">0</p>
            </div>
            <div class="text-right">
                <p class="text-[11px] font-medium uppercase tracking-widest text-red-500 dark:text-red-400">Need
                    Attention</p>
                <p class="text-xl font-bold text-red-600 dark:text-red-400" id="crmAttentionStat">0</p>
            </div>

            <button id="btnNewLead" class="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg">
                + New Prospect
            </button>
        </div>

    </div>

    <!-- Segmented Pipeline Bar -->
    <section class="w-full my-5">
        <div class="flex items-center justify-between mb-2">
            <span class="font-mono text-[11px] uppercase tracking-widest text-zinc-400">Active Pipeline</span>
            <div class="flex items-center gap-2">
                <button type="button" class="statusBtn px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700 hover:opacity-80 transition"
                    data-status="WIN">
                    Won <span id="countWin">0</span>
                </button>
                <button type="button" class="statusBtn px-2.5 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700 hover:opacity-80 transition"
                    data-status="LOST">
                    Lost <span id="countLose">0</span>
                </button>
            </div>
        </div>

        <div id="crmPipelineBar" class="h-2 rounded-full overflow-hidden flex bg-zinc-100 dark:bg-zinc-800">
            <div class="pipeline-segment bg-gray-400" data-status="PROSPECT" style="width: 0%"></div>
            <div class="pipeline-segment bg-indigo-500" data-status="QUALIFIED" style="width: 0%"></div>
            <div class="pipeline-segment bg-purple-500" data-status="OPPORTUNITY" style="width: 0%"></div>
            <div class="pipeline-segment bg-amber-500" data-status="NEGOTIATION" style="width: 0%"></div>
        </div>

        <div class="flex flex-wrap items-center gap-2 mt-3">
            <button type="button"
                class="statusBtn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-dashed border-zinc-300 dark:border-zinc-600 text-xs font-medium text-zinc-500 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition"
                data-status="ALL">
                All <span id="countALL">0</span>
            </button>
            <button type="button"
                class="statusBtn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-zinc-200 dark:border-zinc-700 text-xs font-medium text-zinc-600 dark:text-zinc-300 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition"
                data-status="PROSPECT">
                <span class="w-2 h-2 rounded-full bg-gray-400"></span>
                PROSPECT <span id="countProspect">0</span>
            </button>
            <button type="button"
                class="statusBtn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-zinc-200 dark:border-zinc-700 text-xs font-medium text-zinc-600 dark:text-zinc-300 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition"
                data-status="QUALIFIED">
                <span class="w-2 h-2 rounded-full bg-indigo-500"></span>
                QUALIFIED <span id="countQualified">0</span>
            </button>
            <button type="button"
                class="statusBtn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-zinc-200 dark:border-zinc-700 text-xs font-medium text-zinc-600 dark:text-zinc-300 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition"
                data-status="OPPORTUNITY">
                <span class="w-2 h-2 rounded-full bg-purple-500"></span>
                OPPORTUNITY <span id="countOpportunity">0</span>
            </button>
            <button type="button"
                class="statusBtn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-zinc-200 dark:border-zinc-700 text-xs font-medium text-zinc-600 dark:text-zinc-300 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition"
                data-status="NEGOTIATION">
                <span class="w-2 h-2 rounded-full bg-amber-500"></span>
                NEGOTIATION <span id="countNegotiation">0</span>
            </button>
        </div>
    </section>

    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'tableCrm']); ?>
         <?php $__env->slot('toolbar', null, []); ?> 
            <div class="flex items-center gap-2">
                <label for="crmAssignedToFilter"
                    class="text-[11px] font-medium uppercase tracking-widest text-zinc-500">Assigned
                    Rep</label>
                <select id="crmAssignedToFilter"
                    class="rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 px-3 py-2 text-sm focus:border-orange-500 focus:ring-orange-500">
                    <option value="">All Reps</option>
                </select>
            </div>
            <button type="button" id="crmNeedsAttentionToggle" data-active="false"
                class="inline-flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-widest px-3 py-2 rounded-lg border border-zinc-300 dark:border-zinc-700 text-zinc-500 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition">
                <span aria-hidden="true">⚠</span> Needs Attention
            </button>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>

</div>

<?php if (isset($component)) { $__componentOriginal3e9b58a9d463cc008f1a814a7f792533 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e9b58a9d463cc008f1a814a7f792533 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.prospect-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('prospect-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e9b58a9d463cc008f1a814a7f792533)): ?>
<?php $attributes = $__attributesOriginal3e9b58a9d463cc008f1a814a7f792533; ?>
<?php unset($__attributesOriginal3e9b58a9d463cc008f1a814a7f792533); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e9b58a9d463cc008f1a814a7f792533)): ?>
<?php $component = $__componentOriginal3e9b58a9d463cc008f1a814a7f792533; ?>
<?php unset($__componentOriginal3e9b58a9d463cc008f1a814a7f792533); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal5bec270dee4cf41d2fe5d372aec26e86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bec270dee4cf41d2fe5d372aec26e86 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pm-add-location-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pm-add-location-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bec270dee4cf41d2fe5d372aec26e86)): ?>
<?php $attributes = $__attributesOriginal5bec270dee4cf41d2fe5d372aec26e86; ?>
<?php unset($__attributesOriginal5bec270dee4cf41d2fe5d372aec26e86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bec270dee4cf41d2fe5d372aec26e86)): ?>
<?php $component = $__componentOriginal5bec270dee4cf41d2fe5d372aec26e86; ?>
<?php unset($__componentOriginal5bec270dee4cf41d2fe5d372aec26e86); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal1fe480f19704877e78fd2dbaed8f14d7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1fe480f19704877e78fd2dbaed8f14d7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pm-add-contact-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pm-add-contact-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1fe480f19704877e78fd2dbaed8f14d7)): ?>
<?php $attributes = $__attributesOriginal1fe480f19704877e78fd2dbaed8f14d7; ?>
<?php unset($__attributesOriginal1fe480f19704877e78fd2dbaed8f14d7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1fe480f19704877e78fd2dbaed8f14d7)): ?>
<?php $component = $__componentOriginal1fe480f19704877e78fd2dbaed8f14d7; ?>
<?php unset($__componentOriginal1fe480f19704877e78fd2dbaed8f14d7); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalf8539b6c9d6ee7653bda3d1750ab83d3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8539b6c9d6ee7653bda3d1750ab83d3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pm-add-freight-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pm-add-freight-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8539b6c9d6ee7653bda3d1750ab83d3)): ?>
<?php $attributes = $__attributesOriginalf8539b6c9d6ee7653bda3d1750ab83d3; ?>
<?php unset($__attributesOriginalf8539b6c9d6ee7653bda3d1750ab83d3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8539b6c9d6ee7653bda3d1750ab83d3)): ?>
<?php $component = $__componentOriginalf8539b6c9d6ee7653bda3d1750ab83d3; ?>
<?php unset($__componentOriginalf8539b6c9d6ee7653bda3d1750ab83d3); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal4f2bd5dea2dc732345ee9f5890b81219 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f2bd5dea2dc732345ee9f5890b81219 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pm-add-trucking-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pm-add-trucking-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f2bd5dea2dc732345ee9f5890b81219)): ?>
<?php $attributes = $__attributesOriginal4f2bd5dea2dc732345ee9f5890b81219; ?>
<?php unset($__attributesOriginal4f2bd5dea2dc732345ee9f5890b81219); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f2bd5dea2dc732345ee9f5890b81219)): ?>
<?php $component = $__componentOriginal4f2bd5dea2dc732345ee9f5890b81219; ?>
<?php unset($__componentOriginal4f2bd5dea2dc732345ee9f5890b81219); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal7c15e92d3883dd5e8a984f69179c160b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c15e92d3883dd5e8a984f69179c160b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pm-add-charter-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pm-add-charter-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c15e92d3883dd5e8a984f69179c160b)): ?>
<?php $attributes = $__attributesOriginal7c15e92d3883dd5e8a984f69179c160b; ?>
<?php unset($__attributesOriginal7c15e92d3883dd5e8a984f69179c160b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c15e92d3883dd5e8a984f69179c160b)): ?>
<?php $component = $__componentOriginal7c15e92d3883dd5e8a984f69179c160b; ?>
<?php unset($__componentOriginal7c15e92d3883dd5e8a984f69179c160b); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal18f137382ff831c4e5c5ddc599ac3389 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18f137382ff831c4e5c5ddc599ac3389 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.prospect-info-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('prospect-info-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18f137382ff831c4e5c5ddc599ac3389)): ?>
<?php $attributes = $__attributesOriginal18f137382ff831c4e5c5ddc599ac3389; ?>
<?php unset($__attributesOriginal18f137382ff831c4e5c5ddc599ac3389); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18f137382ff831c4e5c5ddc599ac3389)): ?>
<?php $component = $__componentOriginal18f137382ff831c4e5c5ddc599ac3389; ?>
<?php unset($__componentOriginal18f137382ff831c4e5c5ddc599ac3389); ?>
<?php endif; ?>


<div id="pmDraftDock"
    class="hidden fixed bottom-0 left-0 right-0 lg:left-[var(--sidebar-w,16rem)] z-30 flex items-end gap-3 px-4 overflow-x-auto transition-[left] duration-300 ease-in-out [-webkit-overflow-scrolling:touch]">
</div>

<script>
    (function() {
        initCrmLogic();
        initProspectModal();
        initProspectInfoModal();
        initAddModals();
        initRequestProposalModal();
    })();
</script>
<?php /**PATH C:\xampp\htdocs\kargamine_prototype\resources\views/pages/crm.blade.php ENDPATH**/ ?>