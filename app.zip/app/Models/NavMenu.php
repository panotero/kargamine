<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NavMenu extends Model
{
    protected $casts = [
        'created_at' => 'datetime:M d, Y, h:i A',
        'updated_at' => 'datetime:M d, Y, h:i A',
    ];

    protected $table = 'nav_menus';
    // App\Models\NavMenu.php

    protected $fillable = [
        'title',
        'icon',
        'link',
        'allowed_roles',
        'parent_menu',
        'menu_order',
    ];
}
