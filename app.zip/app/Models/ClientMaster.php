<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ClientMaster extends Model
{
    use HasUuids;

    protected $fillable = [
        'customer_code',
        'company_name',
        'client_mnemonic',
        'client_category',
        'client_classification',
        'industry',
        'sales_rep_id',
        'account_manager_id',
        'current_stage',
        'is_complete',
        'created_by',
        'always_route_atw',
    ];

    protected $casts = [
        'created_at' => 'datetime:M d, Y, h:i A',
        'updated_at' => 'datetime:M d, Y, h:i A',
        'is_complete' => 'boolean',
        'always_route_atw' => 'boolean',
    ];

    public function lead()
    {
        return $this->belongsTo(\App\Models\CrmLead::class, 'lead_id');
    }

    public function addresses()
    {
        return $this->hasMany(ClientAddress::class, 'client_id');
    }

    public function contracts()
    {
        return $this->hasMany(ClientContract::class, 'client_id');
    }

    public function proposals()
    {
        return $this->hasMany(ClientProposal::class, 'client_id');
    }

    /**
     * The user this client "belongs to" for team-scoping - its own
     * sales_rep_id, falling back to the originating lead's assigned rep for
     * clients created before a sales rep was assigned (sales_rep_id is a
     * stage-3 field, not set at creation).
     */
    public function ownerUserId(): ?int
    {
        return $this->sales_rep_id ?? $this->lead?->assigned_to;
    }

    /**
     * Team-scoped visibility, same rule as CRM leads/Proposals: pass
     * TeamService::accessibleUserIds($viewer)->all(), or null to skip the
     * filter entirely (superadmin). Mirrors ownerUserId()'s fallback so a
     * client without a sales rep yet is still matched via its lead.
     */
    public function scopeVisibleTo($query, ?array $userIds)
    {
        if ($userIds === null) {
            return $query;
        }

        return $query->where(function ($q) use ($userIds) {
            $q->whereIn('sales_rep_id', $userIds)
                ->orWhere(function ($q) use ($userIds) {
                    $q->whereNull('sales_rep_id')
                        ->whereHas('lead', fn($q) => $q->whereIn('assigned_to', $userIds));
                });
        });
    }

    public function uniqueIds(): array
    {
        return ['uuid'];
    }

    /**
     * CM-{year}-0001, resetting each year. Finds the current highest
     * sequence for this year across BOTH client_masters and crm_leads
     * (a lead reserves its code here before a ClientMaster row exists),
     * then retries forward past any collision until a free one is found.
     */
    public static function generateNextCustomerCode(): string
    {
        return DB::transaction(function () {
            $prefix = 'CM-' . now()->format('Y') . '-';

            $maxSequenceIn = function (string $table) use ($prefix) {
                return DB::table($table)
                    ->where('customer_code', 'like', "{$prefix}%")
                    ->lockForUpdate()
                    ->pluck('customer_code')
                    ->map(fn($code) => (int) substr($code, strlen($prefix)))
                    ->max() ?? 0;
            };

            $seq = max($maxSequenceIn('client_masters'), $maxSequenceIn('crm_leads'));

            do {
                $seq++;
                $candidate = $prefix . str_pad((string) $seq, 4, '0', STR_PAD_LEFT);
            } while (
                self::where('customer_code', $candidate)->exists()
                || CrmLead::where('customer_code', $candidate)->exists()
            );

            return $candidate;
        });
    }

    public function contacts()
    {
        return $this->hasMany(ClientContact::class, 'client_id');
    }

    public function tradeReferences()
    {
        return $this->hasMany(ClientTradeReference::class, 'client_id');
    }

    public function finance()
    {
        return $this->hasOne(ClientFinance::class, 'client_id');
    }

    public function ancillaryServices()
    {
        return $this->hasMany(ClientAncillaryService::class, 'client_id');
    }

    public function salesRep()
    {
        return $this->belongsTo(User::class, 'sales_rep_id');
    }

    public function accountManager()
    {
        return $this->belongsTo(User::class, 'account_manager_id');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    /**
     * Required fields per stage - used to compute completion.
     */
    public function stageCompletionFlags(): array
    {
        return [
            1 => (bool) ($this->company_name && $this->client_mnemonic && $this->addresses()->exists()),
            2 => $this->contacts()->exists(),
            3 => (bool) ($this->finance && $this->sales_rep_id),
            4 => true, // Ancillary is optional
        ];
    }

    public function recomputeCompletion(): void
    {
        $flags = $this->stageCompletionFlags();
        $this->is_complete = ! in_array(false, $flags, true);
        $this->save();
    }

    /**
     * Not an accessor/append on purpose - calling this unconditionally via
     * $appends would trigger an addresses() lazy-load per row on the
     * paginated client list. Call explicitly (PDF templates, or
     * setAttribute() in a single-record show()) where it's actually needed.
     */
    public function formattedPrimaryAddress(): string
    {
        $address = $this->addresses->firstWhere('is_primary', true) ?? $this->addresses->first();

        if (! $address) {
            return '-';
        }

        return collect([
            $address->address_no,
            $address->address_building,
            $address->address_street,
            $address->address_barangay,
            $address->address_town_city,
            $address->address_province,
            $address->address_country,
            $address->address_postal_code,
        ])->filter()->implode(', ') ?: '-';
    }
}
