<?php

namespace App\Http\Controllers;

use App\Models\MailerSetting;
use App\Models\SettingRole;
use App\Models\User;
use App\Models\UserDepartment;

class PageController extends Controller
{
    public function page_dashboard()
    {
        return view('pages.dashboard');
    }

    public function page_UserManagement()
    {

        return view('pages.settings.usersmanagement');
    }

    public function page_Mailer()
    {

        $config = MailerSetting::latest()->first();

        return view('pages.settings.mailer', compact('config'));
    }

    public function page_Menus()
    {
        return view('pages.settings.menus');
    }

    public function page_Themes()
    {
        return view('pages.settings.theme');
    }

    public function page_NotificationTest()
    {
        return view('pages.settings.notification_test', [
            'roles' => SettingRole::orderBy('role_name')->get(['id', 'role_name']),
            'departments' => UserDepartment::orderBy('name')->get(['id', 'name']),
            'users' => User::orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function page_TeamManagement()
    {
        return view('pages.settings.team_management');
    }

    public function page_Users()
    {
        return view('pages.settings.users');
    }

    public function page_Forms()
    {
        return view('pages.settings.forms');
    }

    public function page_featuredHome()
    {
        return view('pages.featuredHome');
    }

    public function page_settings()
    {
        return view('pages.settings.settings');
    }

    public function page_documents()
    {
        return view('pages.documents');
    }

    public function page_approvals()
    {

        return view('pages.approvals');
    }

    public function page_reports_documents()
    {

        return view('pages.reports.documents');
    }

    public function page_reports_users()
    {
        return view('pages.reports.users');
    }

    public function page_finance_tracker()
    {

        return view('pages.finance');
    }

    public function profile()
    {
        return 'page profile';
    }

    public function settings()
    {
        return 'page settings';
    }

    public function page_contracts()
    {
        return view('pages.contracts');
    }

    public function page_reports()
    {
        return view('pages.reports');
    }

    public function page_crm()
    {

        return view('pages.crm');
    }

    public function page_proposals()
    {
        return view('pages.proposals');
    }

    public function page_maintenance()
    {
        return view('pages.maintenance');
    }

    public function page_clientMasters()
    {
        return view('pages.clientMasters');
    }

    public function page_clientMasterForm()
    {
        return view('pages.clientMasterForm');
    }

    public function page_crmLeadForm()
    {
        return view('pages.crmLeadForm');
    }

    public function page_ContainerInventory()
    {
        return view('pages.containerInventory');
    }

    public function page_Booking()
    {
        return view('pages.booking');
    }

    public function page_BookingForm()
    {
        return view('pages.bookingForm');
    }

    public function page_CargoBuildUp()
    {
        return view('pages.cargoBuildUp');
    }

    public function page_PierCheckin()
    {
        return view('pages.pierCheckin');
    }

    public function page_Help()
    {
        return view('pages.help');
    }
}
